OK_FORMAT = True

test = {   'name': 'q2',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               '>>> from utils.hashing import hash_input\n'
                                               '>>> \n'
                                               '>>> result = generate_prime_numbers(100)\n'
                                               '>>> \n'
                                               '>>> assert hash_input(result) == "0a74d7291764e16982fec9e0483b5aeec03e52f4db369756efeff38741868d9f", "У тебя получился список {result}, что не '
                                               'соответствует всем простым числам от 2 до 100."\n'
                                               '>>> assert len(result) == 25, "Количество простых числел от 2 до 100 должно быть 25."\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
