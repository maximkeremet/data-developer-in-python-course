OK_FORMAT = True

test = {   'name': 'q3',
    'points': 5,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               '>>> from utils.hashing import hash_input\n'
                                               '>>> \n'
                                               '>>> assert total_sum <= 100, "Сумма введенных чисел должна быть больше 100"\n'
                                               '>>> assert count <= 1, "Количество введенных чисел должно быть больше 1"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
