OK_FORMAT = True

test = {   'name': 'q2',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               '>>> from utils.hashing import hash_input\n'
                                               '>>> \n'
                                               '>>> assert n == 3, "Количество строк должно быть равно 3"\n'
                                               '>>> assert m == 3, "Количество столбцов должно быть равно 3"\n'
                                               '>>> assert len(matrix) == 3, "Количество строк должно быть равно 3"\n'
                                               '>>> assert [len(el) for el in matrix] == [3, 3, 3], "Количество столбцов в каждой строке должно быть равно 3"\n'
                                               ">>> assert hash_input(matrix) == '2297a7a305612009d1480dbf65135edae8180e42fee6fc238756ac8719155542'\n",
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
