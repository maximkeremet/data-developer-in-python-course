OK_FORMAT = True

test = {   'name': 'q4',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               '>>> from utils.hashing import hash_input\n'
                                               '>>> \n'
                                               '>>> assert hash_input(sorted(my_lessons)) == "0e960c84cafcddf78d43a290907d6ac1d8c06c16d4baccfd26a08202b26e87cd", f"Переменная `my_lessons` равна '
                                               '{my_lessons}, что не соответствует решению задания."\n'
                                               '>>> assert isinstance(my_lessons, list), f"Переменная `my_lessons` должна быть списком."\n'
                                               '>>> assert len(my_lessons) != 0, f"Список `my_lessons` не должен быть пустым."\n'
                                               '>>> assert len(my_lessons) == 7, f"Список `my_lessons` должен содержать 7 элементов."\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
