OK_FORMAT = True

test = {   'name': 'q1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               '>>> from utils.hashing import hash_input\n'
                                               '>>> \n'
                                               '>>> assert hash_input(example_list) == "a3a1510a4597074a29c1abf38e758dc9e87775bc0e1e200d0bad04b900c8e81d", f"Переменная `example_list` равна '
                                               '{example_list}, что не соответствует решению задания."\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
