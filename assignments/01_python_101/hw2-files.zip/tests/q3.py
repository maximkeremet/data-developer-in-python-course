OK_FORMAT = True

test = {   'name': 'q3',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               '>>> from utils.hashing import hash_input\n'
                                               '>>> \n'
                                               '>>> assert hash_input(fruits) == "72290472f70b4f6bd8b77ddaaaf1aad240c040ea086bfcea8fb214afe17affdf", f"Переменная `fruits` равна {fruits}, что не '
                                               'соответствует решению задания."\n'
                                               '>>> assert fruits.get("Яблоко") == 45, f"Проверь ключ `Яблоко` - значение должно быть равно 45."\n'
                                               '>>> assert fruits.get("Груша") == 50, f"Проверь ключ `Груша` - значение должно быть равно 50."\n'
                                               '>>> assert fruits.get("Бананы") == 50, f"Проверь ключ `Бананы` - значение должно быть равно 50."\n'
                                               '>>> assert fruits.get("Апельсины") == 60, f"Проверь ключ `Апельсины` - значение должно быть равно 60."\n'
                                               '>>> \n'
                                               '>>> def assert_keys_are_capitalized(dictionary):\n'
                                               '...     for key in dictionary.keys():\n'
                                               '...         assert key.istitle(), f"Не все названия фруктов начинаются с большой буквы. {key}"\n'
                                               '>>> \n'
                                               '>>> \n'
                                               '>>> assert_keys_are_capitalized(fruits)\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
