OK_FORMAT = True

test = {   'name': 'q2',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               '>>> from utils.hashing import hash_input\n'
                                               '>>> \n'
                                               '>>> assert hash_input(example_tuple) == "372f6ab13dcc734fd00d9c9ead32f47cda67f6ad392075f96a2fc13fb823ebbb", f"Переменная `example_tuple` равна '
                                               '{example_tuple}, что не соответствует решению задания."\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
