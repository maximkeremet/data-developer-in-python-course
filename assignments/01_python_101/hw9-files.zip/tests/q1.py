OK_FORMAT = True

test = {   'name': 'q1',
    'points': 2,
    'suites': [   {   'cases': [   {   'code': '>>> person = Person("Иван", 25)\n'
                                               '>>> \n'
                                               '>>> assert person.age == 25, "Возраст должен быть 25"\n'
                                               '>>> assert person.name == "Иван", "Имя должно быть Иван"\n'
                                               '>>> assert person.introduce() == "Меня зовут Иван, мне 25 лет.", f"Метод introduce должен возвращать \'Меня зовут Иван, мне 25 лет. Твой метод '
                                               'возвращает: {person.introduce()}\'"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
