OK_FORMAT = True

test = {   'name': 'q3',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               '>>> from utils.hashing import hash_input\n'
                                               '>>> \n'
                                               '>>> account = BankAccount()\n'
                                               '>>> deposit_operation = account.deposit(100)\n'
                                               '>>> withdrawal_operation = account.withdraw(50)\n'
                                               '>>> \n'
                                               '>>> assert hash_input(deposit_operation) == "1930cbf854a75446212a6daad8235797e38d1d8665fcfc76de3770bea31b762e", f\'{deposit_operation}\'\n'
                                               '>>> assert hash_input(withdrawal_operation) == "93b5f6565dad47e6a27f799b389d51d33a8794d56657cd9a7456982a44545ae1"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
