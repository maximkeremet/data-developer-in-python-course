OK_FORMAT = True

test = {   'name': 'q2',
    'points': 3,
    'suites': [   {   'cases': [   {   'code': '>>> \n'
                                               '>>> rectangle = Rectangle(5, 10)\n'
                                               '>>> \n'
                                               '>>> assert rectangle.width == 5, "Ширина должна быть 5"\n'
                                               '>>> assert rectangle.height == 10, "Высота должна быть 10"\n'
                                               '>>> assert rectangle.area() == 50, "Площадь должна быть 50"\n',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
