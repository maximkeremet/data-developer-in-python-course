OK_FORMAT = True

test = {'name': 'q3', 'points': 5, 'suites': [{'cases': [{'code': '>>> \n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
